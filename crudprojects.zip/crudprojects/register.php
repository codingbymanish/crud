<?php
$con = mysqli_connect("localhost", "root", "", "guru");
if (isset($_POST['submit'])) {


    $first = $_POST['first'];
    $last = $_POST['last'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $marital = $_POST['marital'];
    $religion = $_POST['religion'];
    $caste = $_POST['caste'];
    $gotra = $_POST['gotra'];
    $tongue = $_POST['tongue'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $about = $_POST['about'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $highest = $_POST['highest'];
    $photos = $_FILES['photos']['name'];
    $img_path = "upload/".$photos;  
    // $photos = $_POST['photos'];
    // $biodata = $_POST['biodata'];
    $sql = "INSERT INTO `matrimonialdata` (`first` , `last`, `gender`,	`dob` , `marital`,	`religion`	, `caste` , `gotra` , `tongue` , `height` , `weight` , `about` , `email` , `phone` , `address` ,  `country` , `state` , `city` , `highest` ,`photos` ) VALUES ('$first' ,	'$last' ,	'$gender' ,	'$dob' ,	'$marital' ,	'$religion' ,	'$caste' ,	'$gotra' ,	'$tongue' ,	'$height' ,	'$weight' ,	'$about' ,	'$email' ,	'$phone' ,	'$address' ,	'$country' ,	'$state' ,	'$city' ,	'$highest' ,'$img_path ' )";
    $query = mysqli_query($con, $sql); 
    if ($query) {
        move_uploaded_file($_FILES['photos']['tmp_name'], $img_path);
        header("location:matrimonial.php");
    } else {
        echo "<div class='alert alert-danger text-center alert-dismissible'  role='alert' >
          Data not sent ! 
            <button class='btn-close' data-bs-dismiss='alert'></button>
          </div>";
    }
}
// }
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/links.php"; ?>
</head>

<body>

    <?php
    include "include/nav.php";

    ?>

    <div class="container-fluid Constitution">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 mt-5  mb-5">
                            <h1 class="text-white mt-5">Matrimonial</h1>
                            <p class="text-white ">Help today because tomorrow you may be the one who
                                needs more helping! </p>

                            <a href="home1.php" class="text-decoration-none text-white">Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container mt-3">
        <div class="row justify-content-center">
            <div class="col-lg-9 border border-2 rounded-2 p-3">
        
                <form action="" method="post" enctype="multipart/form-data">
                    <h2>User Profile Information</h2>
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>First Name ( पहला नाम )</strong></label>
                            <input type="text" name="first" id="" class="form-control">
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Last Name</strong></label>
                            <input type="text" name="last" id="" class="form-control">
                        </div>

                        <div class="col-lg-12">
                            <label for="" class="form-label mt-2"><strong>Gender (लिंग) </strong></label>
                            <select name="gender" id="" class="form-control">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-lg-12">
                            <label for="" class="form-label  mt-2"><strong>Date of Birth (जन्म की तारीख)</strong></label>
                            <input type="date" name="dob" id="" class="form-control">
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Marital Status (वैवाहिक स्थिति)</strong></label>
                            <select name="marital" id="" class="form-control">
                                <option value="Single">Single</option>
                                <option value="Divorced">Divorced</option>
                                <option value="Widowed">Widowed</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Religion (धर्म)</strong></label>
                            <input type="text" name="religion" id="" class="form-control">
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Caste (जाति)</strong></label>
                            <input type="text" name="caste" id="" class="form-control">
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Gotra (गोत्र)</strong></label>
                            <input type="text" name="gotra"  id="" class="form-control">
                        </div>
                        <div class="col-lg-12">
                            <label for="" class="form-label mt-2"><strong>Mother Tongue (मातृ भाषा)</strong></label>
                            <input type="text" name="tongue" id="" class="form-control">
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Height (लम्बाई)</strong></label>
                            <input type="text" name="height" id="" class="form-control">
                        </div>
                        <div class="col-lg-6">
                            <label for="" class="form-label mt-2"><strong>Weight (वज़न)</strong></label>
                            <input type="text" name="weight" id="" class="form-control">
                        </div>
                        <div class="col-lg-12">

                            <label for="" class="form-label mt-2"><strong>About (अपने बारे में)</strong></label>
                            <textarea name="about" class="form-control" id="" cols="30" rows="5"></textarea>
                        </div>

                        <h2>Contact Information</h2>
                        <div class="col-lg-12">
                            <label for="" class="form-label mt-2"><strong>Email Address (मेल)</strong></label>
                            <input type="text" name="email" id="" class="form-control">
                        </div>
                        <div class="col-lg-12">
                            <label for="" class="form-label mt-2"><strong>Phone Number</strong></label>
                            <input type="text" name="phone" id="" class="form-control">
                        </div>
                        <div class="col-lg-12">

                            <label for="" class="form-label mt-2"><strong>Address</strong></label>
                            <textarea name="address" class="form-control" id="" cols="30" rows="5"></textarea>
                        </div>

                        <div class="col-lg-4 mt-2">
                            <label for="" class="form-label"><strong>Country (देश)</strong></label>
                            <input type="text" class="form-control" name="country">
                        </div>
                        <div class="col-lg-4 mt-2">
                            <label for="" class="form-label "><strong>State (राज्य)</strong></label>
                            <input type="text" class="form-control" name="state">
                        </div>
                        <div class="col-lg-4 mt-2">
                            <label for="" class="form-label"><strong>
                                    City (शहर)</strong></label>
                            <input type="text" class="form-control" name="city">
                        </div>


                        <h2>Education and Career</h2>
                        <div class="col-lg-12">

                            <label for="" class="form-label mt-2"><strong>Highest Qualification (योग्यता)</strong></label>
                            <input type="text" class="form-control" name="highest" id="">
                        </div>

                        <h2>Photos and Documents </h2>
                        <div class="col-lg-12">

                            <label for="" class="form-label mt-2"><strong>Upload Photos</strong></label>
                            <input type="file" class="form-control" name="photos" id="">
                        </div>
                        <!-- <div class="col-lg-12">

                            <label for="" class="form-label mt-2"><strong>Upload Biodata</strong></label>
                            <input type="file" class="form-control" name="biodata" id="">
                        </div> -->
                    </div>
                    <div class="col-lg-2 mt-2">
                        <button class="btn btn-primary" name="submit" type="submit">Submit</button>
                        <button class="btn btn-danger" type="reset">Clear</button>
                    </div>
                    <div class="col-lg-2 mt-2">
                    </div>
                </form>

            </div>
        </div>

    </div>



    <?php include "include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>