<?php 

$con = mysqli_connect("localhost", "root", "", "guru");

$sql = "SELECT * FROM `aboutdata`";
$query = mysqli_query($con, $sql);



?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./include/links.php"; ?>
</head>

<body>

    <?php
    include "./include/nav.php";

    ?>

    <div class="container-fluid Constitution">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 mt-5  mb-5">
                            <h1 class="text-white mt-5">About Us</h1>
                            <p class="text-white mb-5"><a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>HOME</strong></a> &nbsp;&nbsp; &nbsp;<a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>ABOUT</strong></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row mt-5 justify-content-between">
            <div class="col-lg-3">
                <img src="./images/guru.png" alt="" width="100%">
            </div>
            <div class="col-lg-6">
                <h1>
                    About Us</h1>
                <p class="mt-4" style="font-size: 17px ; color:#212529; line-height:27px;">We are a vibrant and close-knit community of people belonging to the esteemed "Chauseni Vaish Samaj," also known by various names such as "Chyavan Vaish," "Chausaini Baniya," and "Chaturshringi Vaish." Our roots are deeply embedded in the reverence of Chyavan Rishi, the revered sage who bestowed the world with the invaluable gift of Chyavanprash.
                </p>
                <button class="btn " style="background-color:rgb(248,184,100);"><a href="" class="text-decoration-none text-white">More About Us</a></button>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
            <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                  <h1 class="mt-5"><?php echo $row['heading']; ?></h1>    
                  <p style="font-size:17px; " class="mt-5"><?php echo $row['para']; ?></p>                       
                    <?php } ?>
            </div>
            <p class="text-center " style="font-size: 17px;"><em>For more information, updates, and to become a part of our vibrant community, please explore our website and stay connected.</em></p>
        </div>
    </div>


    <?php include "./include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>