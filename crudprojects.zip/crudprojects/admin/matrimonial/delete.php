<?php
$con = mysqli_connect("localhost", "root", "", "guru");
$id = $_GET['id'];
$sql = "DELETE FROM `matrimonialdata` WHERE `id`='$id'";
$query = mysqli_query($con, $sql);
if($query){
    header("location:table.php");
}else{
    echo "Data not delete";
}

?>