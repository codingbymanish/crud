<?php

$con = mysqli_connect("localhost", "root", "", "guru");


$data = "SELECT * FROM `matrimonialdata`";
$query = mysqli_query($con, $data);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container-fluid">

        <div class="row " style="background-color: rgb(5,68,104);">
            <div class="col-lg-2  p-3 text-center col-md-3">
                <img src="../download.jpeg" alt="" class="rounded-circle" width="50%">
            </div>
            <div class="col-lg-8 col-lg-7">
                <h1 class="text-white mt-4 text-center">Admin Panel</h1>
            </div>
        </div>

        <div class="row ">

            <div class="col-lg-2" style="background-color: rgb(5,68,104);">
                <ul class="list-unstyled vh-100 mt-5">
                    <h4><a href="../index.php " class="text-decoration-none text-white ">HOME</a></h4>
                    <h4 class="text-white mt-4">ABOUT</h4>
                    <li><a href="../about/form.php" class="text-decoration-none text-white">Add About Data</a></li>
                    <li><a href="../about/table.php" class="text-decoration-none text-white">Manage About Data</a></li>

                    <h4 class="text-white mt-4">CONTACT</h4>
                    <li><a href="../contact/table.php" class="text-decoration-none text-white">Contact Data</a></li>
                    <h4 class="text-white mt-4">Gallery</h4>
                    <li><a href="../gallery/form.php" class="text-decoration-none text-white">Add Gallery Data</a></li>
                    <li><a href="../gallery/table.php" class="text-decoration-none text-white">Manage Gallery Data</a></li>
                    <h4 class="text-white mt-4">Matrimonial</h4>
                    <li><a href="../matrimonial/table.php" class="text-decoration-none text-white">Manage Matrimonial Data</a></li>

                </ul>
            </div>
            <div class="col-lg-10">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="text-center mt-3" style="color:  rgb(5,68,104);">Manage Data of Gallery</h2>
                        <div class="table-responsive">

                            <table class="table table-striped table-responsive">
                                <tr class="table-dark  ">
                                    <td>first </td>
                                    <td>Last </td>
                                    <td>Gender </td>
                                    <td>DOB </td>
                                    <td>Marital </td>
                                    <td>Religion </td>
                                    <td>Caste </td>
                                    <td>Gotra </td>
                                    <td>Tongue </td>
                                    <td>Height </td>
                                    <td>Weight </td>
                                    <td>About </td>
                                    <td>Email </td>
                                    <td>Phone </td>
                                    <td>Address </td>
                                    <td>Country </td>
                                    <td>State </td>
                                    <td>City </td>
                                    <td>Highest </td>
                                    <td>Photos </td>
                                    <!-- <td>Biodata </td> -->
                                    <td>Delete </td>



                                </tr>
                                <?php while ($row = mysqli_fetch_assoc($query)) { ?>

                                    <tr>

                                        <td> <?php echo  $row['first']; ?> </td>
                                        <td> <?php echo  $row['last']; ?> </td>
                                        <td> <?php echo  $row['gender']; ?> </td>
                                        <td> <?php echo  $row['dob']; ?> </td>
                                        <td> <?php echo  $row['marital']; ?> </td>
                                        <td> <?php echo  $row['religion']; ?> </td>
                                        <td> <?php echo  $row['caste']; ?> </td>
                                        <td> <?php echo  $row['gotra']; ?> </td>
                                        <td> <?php echo  $row['tongue']; ?> </td>
                                        <td> <?php echo  $row['height']; ?> </td>
                                        <td> <?php echo  $row['weight']; ?> </td>
                                        <td> <?php echo  $row['about']; ?> </td>
                                        <td> <?php echo  $row['email']; ?> </td>
                                        <td> <?php echo  $row['phone']; ?> </td>
                                        <td> <?php echo  $row['address']; ?> </td>
                                        <td> <?php echo  $row['country']; ?> </td>
                                        <td> <?php echo  $row['state']; ?> </td>
                                        <td> <?php echo  $row['city']; ?> </td>
                                        <td> <?php echo  $row['highest']; ?> </td>
                                        <td> <img src="../<?php  echo $row ['photos'];?>" width="100px" alt=""> </td>
                                        <!-- <td> <?php echo  $row['biodata']; ?> </td> -->
                                        <td><a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger">Delete</a></td>
                                    </tr>
                                <?php } ?>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>