
<div class="container-fluid mt-5" style="background-color: rgb(34,34,34);">
    <div class="row mt-5">
      <div class="col-lg-12">
        <div class="container">
          <div class="row mt-5">
            <div class="col-lg-4 mt-5">
              <img src="images/logo.png" alt="" width="20%">
              <p class="mt-3" style="font-size: 17px; color: #999999;">
                The secret to happiness lies in helping others. Never underestimate the difference YOU can make in the lives of the poor</p>
              <span style="font-size: 14px; color: rgb(248,184,100);" class="ms-4"><i class="fa-brands fa-facebook-f"></i></span>
            </div>
            <div class="col-lg-4 mt-5">
              <h2 class="" style="color: rgb(221,221,221);">Links</h2>
              <ul class="list-unstyled " style="line-height: 40px;">
                <li class="footerli"><a href="" class="text-decoration-none footerli">Home</a></li>
                <li class="footerli"><a href="" class="text-decoration-none footerli">About</a></li>
                <li class="footerli"><a href="" class="text-decoration-none footerli">Gallery</a></li>
                <li class="footerli"><a href="" class="text-decoration-none footerli">Matrimonial Site</a></li>
                <li class="footerli"><a href="" class="text-decoration-none footerli">Contact</a></li>
                <li class="footerli"><a href="" class="text-decoration-none footerli">Donation</a></li>
              </ul>
            </div>
            <div class="col-lg-4 mt-5 footerbg">
              <h2 class="" style="color: rgb(221,221,221);">Location</h2>
              <ul class="list-unstyled">
                <li class="mt-3">
                  <i class="fa-solid fa-envelope" style=" color: rgb(248,184,100);"></i>
                  <a href="" class="footera text-decoration-none"> abchauseniindia@gmail.com</a>
                </li>

                <li class="mt-3">
                  <i class="fa-solid fa-phone" style=" color: rgb(248,184,100);"> </i>
                  <a href="" class="text-decoration-none footera"> +91 9953978616</a>
                </li>

                <li class="mt-3">
                  <i class="fa-solid fa-globe" style=" color: rgb(248,184,100);"></i>
                  <a href=" www.chausenivaishy.com" class="text-decoration-none footera"> www.chausenivaishy.com</a>
                </li>

                <li class="mt-3">
                  <i class="fa-solid fa-location-dot" style=" color: rgb(248,184,100);"></i>
                  <a href="" class="text-decoration-none footera"> Plot No. 32, First Floor, Gali No. 12, Parampuri Chowk, Block S Parampuri, Uttam Nagar, New Delhi - 110059</a>
                </li>
              </ul>


            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid footer" style="background-color: rgb(34,34,34);">
    <div class="row">
      <div class="col-lg-12">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 mt-4 mb-2">
              <p class="" style="font-size: 15px; color: #DDDDDD;">© 2023 Powered by Chausenivaishy</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>