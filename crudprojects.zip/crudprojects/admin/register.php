<?php 
$con = mysqli_connect("localhost", "root" , "" , "guru");


if(isset($_POST['submit'])){
$username = $_POST["username"];
$password = $_POST["password"];
$sql = "SELECT * FROM `logindata` WHERE `username`='$username' and `password` = '$password'";
$query = mysqli_query($con, $sql);  
$match = mysqli_num_rows($query);


if ($match){
    echo " <p class='text-white'>User already Exist</p>";
}else{
    $sql1 = "INSERT INTO `logindata` (`username` , `password` ) VALUES ('$username' , '$password')";
    $query1 = mysqli_query($con, $sql1);
if($query1){
echo "<p class='text-white'>data sent</p>";
}
}
}
?>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .alert {
            position: absolute;
            top: 0;
            width: 100%;
        }
    </style>
</head>

<body  class="bg-dark">


    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-lg-4 mt-5 ">
                <form action="" method="post" class="border-3 border p-4 rounded-4">
                    <h1 class="text-white">REGISTER</h1>
                    <label for="" class="form-label mt-3 text-white">Email</label>
                    <input type="email" name="username" id="" class="form-control rounded-4 border-2 border text-white" style="background-color: transparent;">
                    <label for="" class="form-label mt-3 text-white">Password</label>
                    <input type="text" name="password" id="" class="form-control rounded-4 border-2 border text-white" style="background-color: transparent;">
                    <input type="submit" name="submit"  value="login" class="btn btn-info rounded-4 mt-3  w-75 text-white">
                </form>
            </div>
        </div>
    </div>
    <script src="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>