<ul class="list-unstyled vh-100">
    <h4 class="text-white mt-4">ABOUT</h4>
    <li><a href="" class="text-decoration-none text-dark">Add About Data</a></li>
    <li><a href="abouttable/table.php" class="text-decoration-none text-dark">Manage  About Data</a></li>

    <h4 class="text-white mt-4">CONTACT</h4>
    <li><a href="contact/table.php" class="text-decoration-none text-dark">Contact Data</a></li>
</ul>