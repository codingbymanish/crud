<?php 

$con = mysqli_connect("localhost" , "root" , "" , "guru");
session_start();

if (isset($_POST['submit'])) {

    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con , $_POST['password']);

    $sql = "SELECT * FROM `logindata` WHERE `username` = '$username' and `password` = '$password'";
    $query = mysqli_query($con, $sql);
    $match = mysqli_num_rows($query);
    if ($match) {
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        header("location:index.php");
    }else{
        echo "<p class='text-center text-white'>User Or Password Is Invalid <p/>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .alert {
            position: absolute;
            top: 0;
            width: 100%;
        }
    </style>
</head>

<body  class="bg-dark">


    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-lg-4 mt-5 ">
                <form action="" method="post" class="border-3 border p-4 rounded-5">
                    <h1 class="text-white">LOGIN</h1>
                    <label for="" class="form-label mt-3 text-white">Email</label>
                    <input type="email" name="username" id="" class="form-control rounded-5 border-2 border text-white shadow-none" style="background-color: transparent;">
                    <label for="" class="form-label mt-3 text-white">Password</label>
                    <input type="text" name="password" id="" class="form-control rounded-5 border-2 border text-white shadow-none" style="background-color: transparent;">
                  
                    <input type="submit" name="submit" value="Login" class="btn btn-info rounded-5 mt-3  w-100 text-white">
                </form>
            </div>
        </div>
    </div>
    <script src="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>