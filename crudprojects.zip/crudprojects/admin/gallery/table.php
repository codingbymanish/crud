<?php 

$con = mysqli_connect("localhost" , "root" , "" , "guru");


$data = "SELECT * FROM `gallerydata`";
$query = mysqli_query($con, $data);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container-fluid">

        <div class="row " style="background-color: rgb(5,68,104);">
            <div class="col-lg-2 p-3 text-center  col-md-3">
                <img src="../download.jpeg" alt="" class="rounded-circle" width="50%">
            </div>
            <div class="col-lg-8 col-lg-7">
                <h1 class="text-white mt-4 text-center">Admin Panel</h1>
            </div>
        </div>

        <div class="row ">

            <div class="col-lg-2" style="background-color: rgb(5,68,104);">
                <ul class="list-unstyled vh-100 mt-5">
                    <h4><a href="../index.php " class="text-decoration-none text-white ">HOME</a></h4>
                    <h4 class="text-white mt-4">ABOUT</h4>
                    <li><a href="../about/form.php" class="text-decoration-none text-white">Add About Data</a></li>
                    <li><a href="../about/table.php" class="text-decoration-none text-white">Manage About Data</a></li>

                    <h4 class="text-white mt-4">CONTACT</h4>
                    <li><a href="../contact/table.php" class="text-decoration-none text-white">Contact Data</a></li>
                    <h4 class="text-white mt-4">Gallery</h4>
                    <li><a href="../gallery/form.php" class="text-decoration-none text-white" >Add Gallery Data</a></li>
                    <li><a href="../gallery/table.php" class="text-decoration-none text-white" >Manage Gallery Data</a></li>
                    <h4 class="text-white mt-4">Matrimonial</h4>
                    <li><a href="../matrimonial/table.php" class="text-decoration-none text-white" >Manage Matrimonial Data</a></li>
                </ul>
            </div>
            <div class="col-lg-10">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="text-center mt-3" style="color:  rgb(5,68,104);">Manage Data of Gallery</h2>
                        <table class="table table-striped">
                    <tr class="table-dark">
                    
                        <td>Image</td>
                        <td>Update</td>
                        <td>Delete</td>
                       
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                      
                        <tr>
                      <td><img src="../<?php echo  $row['img']?>" width="15%" alt=""></td>
                      <td><a href="update.php?id=<?php echo $row['id'];?>" class="btn btn-primary">Update</a></td>
                      <td><a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger">Delete</a></td>
                        </tr>   
                    <?php } ?>
                </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>