<?php
$con = mysqli_connect("localhost", "root", "", "guru");
if (isset($_POST['submit'])) {
    $img = $_FILES['img']['name'];
    $img_path = "upload/".$img;

    $sql = "INSERT INTO `gallerydata` (`img` ) VALUES  ('$img_path') ";
    move_uploaded_file($_FILES['img']['tmp_name'], $img_path);
    $query = mysqli_query($con, $sql);
    header("location:table.php");
    
    
    if ($query) {
        "<div class='alert alert-primary text-center alert-dismissible'  role='alert' >
        Data sent successfully... 
        <button class='btn-close' data-bs-dismiss='alert'></button>
        </div>";
        
    } else {
        echo "<div class='alert alert-danger text-center alert-dismissible'  role='alert' >
      Data not sent ! 
        <button class='btn-close' data-bs-dismiss='alert'></button>
      </div>";
    }
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="../upload/"> -->
</head>


<body>
    <div class="container-fluid">
    <div class="row " style="background-color: rgb(5,68,104);">
    <div class="col-lg-2  p-3 text-center col-md-3">
        <img src="../download.jpeg" alt="" class="rounded-circle" width="50%">
    </div>
    <div class="col-lg-8 col-lg-7">
        <h1 class="text-white mt-4 text-center">Admin Panel</h1>
    </div>
</div>

        <div class="row ">

            <div class="col-lg-2" style="background-color: rgb(5,68,104);">
                <ul class="list-unstyled vh-100 mt-5">
                    <h4><a href="../index.php " class="text-decoration-none text-white ">HOME</a></h4>
                    <h4 class="text-white mt-4">ABOUT</h4>
                    <li><a href="../about/form.php" class="text-decoration-none text-white"  >Add About Data</a></li>
                    <li><a href="../about/table.php" class="text-decoration-none text-white" >Manage About Data</a></li>

                    <h4 class="text-white mt-4">CONTACT</h4>
                    <li><a href="../about/table.php" class="text-decoration-none text-white" >Contact Data</a></li>
                    <h4 class="text-white mt-4">Gallery</h4>
                    <li><a href="../gallery/form.php" class="text-decoration-none text-white" >Add Gallery Data</a></li>
                    <li><a href="../gallery/table.php" class="text-decoration-none text-white" >Manage Gallery Data</a></li>
                    <h4 class="text-white mt-4">Matrimonial</h4>
                    <li><a href="../matrimonial/table.php" class="text-decoration-none text-white" >Manage Matrimonial Data</a></li>
                </ul>
            </div>
            <div class="col-lg-10">
                <div class="row justify-content-center">
                    <div class="col-lg-6">

                    <form action="" method="post" class="mt-5  p-5" style="border: 2px solid rgb(5,68,104);" enctype="multipart/form-data">
                    <h2 class="text-center " style="color: rgb(5,68,104);">Add Data in Gallery  Section</h2>
                    <input type="file" name="img" class="form-control rounded-0 mt-5" placeholder="file"   style="border: 2px solid rgb(5,68,104);">

                    <!-- <input type="file" name="heading" id="" class="form-control rounded-0 mt-5" style="border: 2px solid rgb(5,68,104);" placeholder="Heading"> -->
                    <button class="btn text-white mt-5 " type="submit" name="submit" style="background-color:rgb(5,68,104);">Add Data</button>

                </form>
                    </div>
                </div>
           
            </div>
        </div>
    </div>


</body>

</html>