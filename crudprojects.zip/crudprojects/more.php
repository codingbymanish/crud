<?php
$con = mysqli_connect("localhost", "root", "", "guru");
$id = $_GET['id'];
$sql = "SELECT * FROM `matrimonialdata`";
$query = mysqli_query($con, $sql);
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./include/links.php"; ?>
</head>

<body>

    <?php
    include "./include/nav.php";

    ?>

    <div class="container-fluid matri">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 mt-2  mb-5">
                            <h2 class="text-white mt-5">Matrimonial Search</h2>

                            <form action="">

                                <div class="row">

                                    <div class="col-lg-6">
                                        <label for="" class="form-label text-white">Marital Status:</label>
                                        <input type="text" class="form-control">
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="" class="form-label text-white">Religion:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-4">
                                        <label for="" class="form-label text-white">Caste:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="" class="form-label text-white">Gotra:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="" class="form-label text-white">Qualification:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <button class="form-control mt-4 btn-primary btn">Search</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">

        <div class="row">
            <div class="col-lg-12">
                <?php

                $sel = "SELECT * FROM `matrimonialdata` WHERE `id`='$id'";
                $query1 = mysqli_query($con, $sel);
                $row = mysqli_fetch_assoc($query1);


                ?>

 
                <div class="card mt-5 border-0">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="img">
                                <img src="admin/<?php echo $row['photos'];  ?>" width="100%" alt="">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card-body">


                                <h3>Profile Information</h3>
                                <div class="row">
                                    <div class="col-lg-6">

                                        <p><strong>First Name: </strong> <?php echo $row['first']; ?></p>
                                        <p><strong>Last Name: </strong> <?php echo $row['last']; ?></p>
                                        <p><strong>Gender: </strong> <?php echo $row['gender']; ?></p>
                                        <p><strong>Date of Birth: </strong> <?php echo $row['dob']; ?></p>
                                        <p><strong>Marital Status: </strong><?php echo $row['marital']; ?></p>
                                        <p><strong>Religion: </strong> <?php echo $row['religion']; ?></p>
                                    </div>

                                    <div class="col-lg-6">
                                        <p><strong>Caste: </strong> <?php echo $row['caste']; ?></p>
                                        <p><strong>Gotra: </strong> <?php echo $row['gotra']; ?></p>
                                        <p><strong>Mother Tongue: </strong> <?php echo $row['tongue']; ?></p>
                                        <p><strong>Height </strong><?php echo $row['height']; ?></p>
                                        <p><strong>Weight: </strong><?php echo $row['weight']; ?></p>
                                        <p><strong>Religion: </strong><?php echo $row['religion']; ?></p>
                                    </div>
                                    <div class="col-lg-6">
                                        <h3>Contact Information</h3>
                                        <p><strong>Email Address: </strong><?php echo $row['email']; ?></p>
                                        <p><strong>Phone No: </strong> <?php echo $row['phone']; ?></p>
                                        <p><strong>Address: </strong> <?php echo $row['address']; ?></p>
                                        <p><strong>Country: </strong> <?php echo $row['country']; ?></p>
                                        <p><strong>State: </strong><?php echo $row['state']; ?></p>
                                        <p><strong>City: </strong> <?php echo $row['city']; ?></p>
                                    </div>
                                    <div class="col-lg-6">
                                        <h3>Education and Career</h3>
                                        <p><strong>Highest Qualification: <?php echo $row['highest']; ?></strong></p>
                                        <a href="home1.php" class="btn text-white" style="background-color:rgb(248,184,100);">Home</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
              
            </div>
        </div>
    </div>


    <?php include "./include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>