<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./include/links.php"; ?>
    </head>

<body>

    <?php
    include "./include/nav.php";

    ?>

    <div class="container-fluid Constitution">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 mt-3  mb-5">
                            <h1 class="text-white mt-5">Our Constitution</h1>
                            <p class="text-white" style="font-size: 17px ; color:#DDDDDD;  line-height:25px;">Help today because tomorrow you may be the one who
                                needs more helping!</p>
                            <p class="text-white mb-5"><a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>HOME</strong></a> &nbsp;&nbsp; &nbsp;<a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>OUR CONSTITUTION</strong></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <h1 class="text-center mt-5">Our Constitution</h1>
            <div class="col-lg-12">
                <div class="row ">
                    <div class="owl-carousel " id="owlfirst">
                        <div class="item">
                            <img src="./images/constitution1.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution2.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution3.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution4.jpg" alt="">
                        </div>

                        <div class="item">
                            <img src="./images/constitution5.jpg" alt="">
                        </div>

                        <div class="item">
                            <img src="./images/constitution6.jpg" alt="">
                        </div>

                        <div class="item">
                            <img src="./images/constitution7.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution8.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution13.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution14.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution15.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution16.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution21.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution22.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution23.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./images/constitution24.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="./js/main.js"></script>
    <script src="./js/owl.js"></script>
    <script>
        $('#owlfirst').owlCarousel({
            loop: true,
            margin: 10,
            responsiveClass: true,
            autoplayTimeout: 1200,
            autoplay: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true
                },
                600: {
                    items: 3,
                    nav: false
                },
                1000: {
                    items: 4,
                    nav: true,
                    loop: true
                }
            }
        });
    </script>
    <?php include "./include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>