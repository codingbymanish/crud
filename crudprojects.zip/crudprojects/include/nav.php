<div class="container-fluid" style="background-color: rgb(248,184,100);">
    <div class="row">
      <div class="col-lg-12">
        <div class="container">

          <div class="row text-white justify-content-between">
            <div class="col-lg-7 col-md-8  p-3">
              <div class="row">
                <div class="col-lg-5 col-md-6">
                  <span style="font-size: 14px;"><i class="fa-regular fa-envelope"></i> abchauseniindia@gmail.com</span>
                </div>
                <div class="col-lg-5 col-md-6">
                  <span style="font-size: 14px;"><i class="fa-solid fa-phone"></i> +91-9953978616</span>

                </div>
              </div>

            </div>
            <div class="col-lg-3  col-md-4  text-end p-3 facebook">
              <span style="font-size: 14px;"><i class="fa-brands fa-facebook-f"></i></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="container-fluid mainnavbar bg-white" data-aos="fade-down">
    <div class="row">
      <div class="col-lg-12">
        <div class="container">
          <div class="row">


            <nav class="navbar navbar-expand-lg navbar-light bg-light p-0">
              <!-- <div class="container-fluid"> -->
              <a class="navbar-brand p-0" href="#"><img src="./images/logo.png " width="18%" alt=""></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item"><a class="nav-link  text-dark  " href="index.php"><strong>Home</strong></a></li>
                  <li class="nav-item"><a class="nav-link  text-dark  " href="about.php"><strong>About</strong></a></li>
                  <li class="nav-item "><a class="nav-link text-dark  " href="gallery.php"><strong>Gallery</strong></a></li>
                  <li class="nav-item "><a class="nav-link text-dark  " href="matrimonial.php"><strong>Matrimonial</strong></a></li>
                  <li class="nav-item "><a class="nav-link text-dark  " href="contact.php"><strong>Contact</strong></a></li>
                  <li class="nav-item "><a class="nav-link text-dark " href="member.php"><strong>Member Details </strong></a>
                  </li>
                  <li class="nav-item "><a class="nav-link text-dark " href="constition.php"><strong>Our Constitution</strong></a>
                  </li>
                  <button class="btn text-white navbutton " style="background-color: rgb(248,184,100);">Donate
                    Now</button>

                </ul>

                <!-- </div> -->
              </div>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
