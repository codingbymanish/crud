<?php
$con = mysqli_connect("localhost" , "root" , "" , "guru");
if(isset($_POST['submit'])){
    if(empty($_POST['name']) || empty($_POST['email'])|| empty($_POST['message']) ){
        echo "<div class='alert alert-danger text-center alert-dismissible'  role='alert' >
        Please Enter  Your Data ! 
        <button class='btn-close' data-bs-dismiss='alert'></button>
      </div>";
    }else{
        $name = ucfirst($_POST['name']);    
        $email = $_POST['email'];
        $message = ucfirst($_POST['message']);
        $sql = "INSERT INTO `maincontactform` (`name` , `email` ,`message`) VALUES ('$name' , '$email' ,'$message')";
        $query = mysqli_query($con, $sql);
        if ($query) {
            header("location:index.php");
        } else {
            echo "<div class='alert alert-danger text-center alert-dismissible'  role='alert' >
          Data not sent ! 
            <button class='btn-close' data-bs-dismiss='alert'></button>
          </div>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./include/links.php"; ?>
   
</head>

<body>

    <?php
    include "./include/nav.php";

    ?>

    <div class="container-fluid Constitution">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 mt-3  mb-5">
                            <h1 class="text-white mt-5">Contact With Us</h1>
                            <p class="text-white" style="font-size: 17px ; color:#DDDDDD;  line-height:25px;">Help today because tomorrow you may be the one who
                                needs more helping!</p>
                            <p class="text-white mb-5"><a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>HOME</strong></a> &nbsp;&nbsp; &nbsp;<a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>Contact </strong></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 g-0">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3502.453911423919!2d77.051392!3d28.616155!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d05a06afb1e19%3A0x8945a5556c01fa1f!2sPLOT%20NO%20-%20A10%2C%20NANHEY%20PARK%2C%20MATIYALA%20ROAD%2C%20UTTAM%20NAGAR%2C%20NEW%20DELHI!5e0!3m2!1sen!2sin!4v1709807305953!5m2!1sen!2sin" width="100%" height="400px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
    <div class="container " style="box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; background-color:rgb(242,242,242);" >
        <div class="row p-5 ">
            <div class="col-lg-6 mt-4">
                <p>Plot No. 32, First Floor, Gali No. 12, Parampuri Chowk, Block S Parampuri, Uttam Nagar, New Delhi - 110059</p>
                <p>Tel. No. +91-9953978616</p>
                <p>Email: abchauseniindia@gmail.com</p>
                <p>Follow on: <a href="" class="text-decoration-none" style="color: rgb(0,104,158);">Facebook</a> </p>
                <p>Website: <a href=" https://chausenivaishy.com/"> https://chausenivaishy.com/</a></p>
            </div>
            <div class="col-lg-6 mt-4   ">
                <h5>DROP US A LINE</h5>
                <p>Send You Details for More Communication</p>

            
                <form action="" method="post">
                <div class="row">
                   <div class="col-lg-6">
                        <input type="text" name="name" id=""  class="form-control rounded-0" placeholder="Name">
                    </div>
                    <div class="col-lg-6">
                    <input type="email" name="email" id="" class="form-control rounded-0" placeholder="Email">

                    </div>
                    <div class="col-lg-12">
                        <textarea name="message" id="" cols="30" rows="5" class="form-control rounded-0 mt-3" placeholder="Message"></textarea>
                        <button class="btn text-white mt-3 " type="submit" name="submit" style="background-color: rgb(248,184,100) ;">Send Message</button>
                    </div>
                    
                </div>
            </form>
            </div>
        </div>
    </div>

    <?php include "./include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>