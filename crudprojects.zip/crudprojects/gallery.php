<?php
$con = mysqli_connect("localhost", "root", "", "guru");

$data = "SELECT * FROM `gallerydata`";
$query = mysqli_query($con, $data);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./include/links.php"; ?>
</head>

<body>

    <?php
    include "./include/nav.php";

    ?>

    <div class="container-fluid Constitution">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 mt-3  mb-5">
                            <h1 class="text-white mt-5">Image Gallery</h1>
                            <p class="text-white" style="font-size: 17px ; color:#DDDDDD;  line-height:25px;">Help today because tomorrow you may be the one who
                                needs more helping!</p>
                            <p class="text-white mb-5"><a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong>HOME</strong></a> &nbsp;&nbsp; &nbsp;<a href="" class="text-decoration-none text-white" style="font-size:12px;"><strong> Gallery </strong></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row mt-5">

            <?php while ($row = mysqli_fetch_assoc($query)) { ?>
            <div class="col-lg-4 mt-5">
                    <div class="card ">

                        <img src="admin/<?php echo $row['img']  ?>" width="100%" alt="">
                    </div>
                    
                </div>
                <?php } ?>
        </div>
    </div>
    <?php include "./include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>