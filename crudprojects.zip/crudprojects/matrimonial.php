<?php
$con = mysqli_connect("localhost", "root", "", "guru");
$sql = "SELECT * FROM `matrimonialdata`";   
$query = mysqli_query($con, $sql);
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./include/links.php"; ?>
</head>

<body>

    <?php
    include "./include/nav.php";

    ?>

    <div class="container-fluid matri">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 mt-2  mb-5">
                            <h2 class="text-white mt-5">Matrimonial Search</h2>

                            <form action="">

                                <div class="row">

                                    <div class="col-lg-6">
                                        <label for="" class="form-label text-white">Marital Status:</label>
                                        <input type="text" class="form-control">
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="" class="form-label text-white">Religion:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-4">
                                        <label for="" class="form-label text-white">Caste:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="" class="form-label text-white">Gotra:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="" class="form-label text-white">Qualification:</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <button class="form-control mt-4 btn-primary btn">Search</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row mt-4 justify-content-between">
            <div class="col-lg-3 col-md-4">
                <h2>User Information</h1>
            </div>
            <div class="col-lg-2 text-end col-md-3">
                <a href="register.php" class="text-decoration-none text-white btn" style="background-color: rgb(248,184,100);">Register</a>
            </div>
        </div>
        <div class="row">
            <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                <div class="col-lg-4 mt-5">
                    <div class="card border-0">
                        <div class="img">
                            <img src="admin/<?php echo $row['photos']; ?>" width="100%    " alt="">
                        </div> 
                        <div class="card-body">
                            <p><strong>First Name: <?php echo $row['first']; ?></strong></p>
                            <p><strong>Last Name: <?php echo $row['last']; ?></strong></p>
                            <p><strong>Gender: <?php echo $row['gender']; ?></strong></p>
                            <p><strong>Date of Birth: <?php echo $row['dob']; ?></strong></p>
                            <p><strong>Marital Status:<?php echo $row['marital']; ?></strong></p>
                            <p><strong>Religion: <?php echo $row['religion']; ?></strong></p>
                            <button class="btn " style="background-color:rgb(248,184,100);"> <a href="more.php?id=<?php echo $row['id'] ?>" class="text-decoration-none text-white">Read More</a></button>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>


    <?php include "./include/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>